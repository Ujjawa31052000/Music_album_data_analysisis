-- Q1 : Retrive the total no. of order placed 

select count(order_detail_id) as total from order_id;