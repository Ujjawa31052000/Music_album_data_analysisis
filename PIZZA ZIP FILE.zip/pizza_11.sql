-- Analyse the cumulative revenue generated over time

SELECT 
    order_date, 
    SUM(revenue) OVER (ORDER BY order_date) AS cum_revenue
FROM 
    (SELECT 
         pizza_order.order_date,
         SUM(order_details.quantity * pizzas.price) AS revenue 
     FROM order_details 
     JOIN pizzas ON order_details.pizza_id = pizzas.pizza_id
     JOIN order_id ON order_id.pizza_order_id = order_details.pizza_order_id
     GROUP BY pizza_order.order_date
    ) AS sales;
